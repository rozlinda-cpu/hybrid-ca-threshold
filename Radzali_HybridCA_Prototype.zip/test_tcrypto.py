import os, sys, secrets
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tcrypto as tc
from gmpy2 import mpz


def test_metadata():
    m = tc.encode_metadata('RSA', 2048, 1, 1759017600, 3, 5)
    assert len(m) == 16
    assert tc.decode_metadata(m)['t'] == 3 and tc.decode_metadata(m)['n'] == 5
    d1 = tc.digest(m)
    d2 = tc.digest(tc.encode_metadata('RSA', 2048, 1, 1759017600, 3, 6))
    assert d1 != d2
    assert tc.composite_digest([d1, d2]) == tc.composite_digest([d2, d1])


def test_threshold_rsa(bits=1024):
    for (t, n) in [(2, 3), (3, 5), (4, 7)]:
        pk, shares = tc.deal(bits, n, t)
        msg = b'hello metadata'
        # every t-subset combination works (sampled)
        for _ in range(5):
            S = sorted(secrets.SystemRandom().sample(range(n), t))
            parts = [tc.partial_sign(shares[i], msg) for i in S]
            assert all(tc.verify_partial(pk, msg, p) for p in parts)
            y = tc.combine(pk, msg, parts)
            assert pk.verify(msg, y)
            assert not pk.verify(msg + b'x', y)
        # malicious node: wrong share -> proof fails, robust_sign excludes it
        bad = tc.KeyShare(1, shares[0].s + 1, pk)
        parts = [tc.partial_sign(bad, msg)] + [tc.partial_sign(s, msg) for s in shares[1:]]
        y, rejected = tc.robust_sign(pk, msg, parts)
        assert rejected == [1] and pk.verify(msg, y)
        # fewer than t partials -> no signature
        y, _ = tc.robust_sign(pk, msg, parts[1:t])
        assert y is None
    print('threshold RSA ok')


def test_bd(m_values=(2, 3, 4, 5, 8)):
    for m in m_values:
        P = [tc.BDParty(i, m) for i in range(m)]
        zs = [p.round1() for p in P]
        Xs = [p.round2(zs) for p in P]
        keys = {p.key(Xs) for p in P}
        assert len(keys) == 1, m
        # expected value g^{sum r_i r_{i+1}}
        e = sum(P[i].r * P[(i + 1) % m].r for i in range(m))
        assert keys.pop() == tc.powmod(tc.G, e, tc.P2048)
    print('BD ok')


def test_session_binding():
    m = 3
    P = [tc.BDParty(i, m) for i in range(m)]
    zs = [p.round1() for p in P]
    Xs = [p.round2(zs) for p in P]
    K = P[0].key(Xs)
    sid = os.urandom(16)
    hx1 = tc.composite_digest([tc.digest(tc.encode_metadata(a, 2048 if a == 'RSA' else 256, 1, 1759017600, 3, 5))
                               for a in ('RSA', 'ECDSA-P256', 'ECDSA-P256')])
    hx2 = tc.composite_digest([tc.digest(tc.encode_metadata(a, 2048 if a == 'RSA' else 256, 2, 1759017600, 3, 5))
                               for a in ('RSA', 'ECDSA-P256', 'ECDSA-P256')])
    assert tc.session_key(K, hx1, sid, zs, Xs) != tc.session_key(K, hx2, sid, zs, Xs)
    print('session binding ok')


if __name__ == '__main__':
    test_metadata(); test_threshold_rsa(); test_bd(); test_session_binding()
    print('ALL TESTS PASSED')
