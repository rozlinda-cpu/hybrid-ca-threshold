"""Turns Docker/netem testbed results (docker_results.zip or a folder of JSON files) into the
paper's testbed figure and table.

  python analysis_testbed.py docker_results.zip
  python analysis_testbed.py testbed/run/results
"""
import glob, io, json, os, re, statistics, sys, zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

D = os.path.dirname(os.path.abspath(__file__))
F = os.path.join(D, 'figures'); os.makedirs(F, exist_ok=True)
T = os.path.join(D, 'tables'); os.makedirs(T, exist_ok=True)
C = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100']
MK = ['o', 's', '^', 'D']
TXT2, GRID = '#52514e', '#e4e3df'
plt.rcParams.update({'font.family': 'serif', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.6, 'legend.frameon': False,
                     'lines.linewidth': 2, 'lines.markersize': 5, 'xtick.color': TXT2, 'ytick.color': TXT2})
LABEL = re.compile(r'(?:docker|colab)_(S\d)_m(\d+)_t(\d+)n(\d+)_(robust|optimistic)')
SC_NAME = {'S1': 'S1 single region', 'S2': 'S2 continental', 'S3': 'S3 intercontinental', 'S4': 'S4 S3 + dispersed nodes'}


def load(src):
    docs = []
    if src.endswith('.zip'):
        with zipfile.ZipFile(src) as z:
            for n in z.namelist():
                if n.endswith('.json'):
                    docs.append(json.load(io.TextIOWrapper(z.open(n), encoding='utf-8')))
    else:
        for f in glob.glob(os.path.join(src, '*.json')):
            docs.append(json.load(open(f)))
    return docs


def q(xs, p):
    xs = sorted(xs)
    if len(xs) == 1:
        return xs[0]
    k = (len(xs) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def main(src, name='testbed'):
    recs = []
    for d in load(src):
        s = d['summary']
        m = LABEL.search(s['label'])
        if not m:
            continue
        sc, mm, t, n, mode = m.group(1), int(m.group(2)), int(m.group(3)), int(m.group(4)), m.group(5)
        lat = [max(x['total_ms'] for x in r['rcas']) for r in d['rows']]
        tsig = [x['tsig_ms'] for r in d['rows'] for x in r['rcas']]
        comp = [x['compute_ms'] for r in d['rows'] for x in r['rcas']]
        inter, intra = float(s['env']['INTER_RTT_MS']), float(s['env']['INTRA_RTT_MS'])
        recs.append(dict(scenario=sc, m=mm, t=t, n=n, mode=mode, inter=inter, intra=intra,
                         delay=','.join(s['env'].get('DELAY_MODE_EFFECTIVE', ['?'])),
                         sessions=len(lat), keys_agreed=s.get('all_keys_agreed', False),
                         lat_med=statistics.median(lat), lat_q1=q(lat, .25), lat_q3=q(lat, .75),
                         tsig_med=statistics.median(tsig), comp_med=statistics.median(comp),
                         floor=inter + intra))
    if not recs:
        sys.exit('no testbed results found in ' + src)
    recs.sort(key=lambda r: (r['mode'] != 'optimistic', r['scenario'], r['m']))
    modes = [mo for mo in ('optimistic', 'robust') if any(r['mode'] == mo for r in recs)]

    # ---------------- figure: one panel per mode, shared y axis
    fig, axes = plt.subplots(1, len(modes), figsize=(3.4 * len(modes), 2.9), sharey=True, squeeze=False)
    ymax = max(r['lat_q3'] for r in recs) * 1.1
    for ax, mo in zip(axes[0], modes):
        for k, sc in enumerate(['S1', 'S2', 'S3', 'S4']):
            rs = [r for r in recs if r['mode'] == mo and r['scenario'] == sc]
            if not rs:
                continue
            xs = [r['m'] for r in rs]
            ax.plot(xs, [r['lat_med'] for r in rs], color=C[k], marker=MK[k], label=SC_NAME[sc])
            ax.fill_between(xs, [r['lat_q1'] for r in rs], [r['lat_q3'] for r in rs], color=C[k], alpha=0.15, lw=0)
            ax.plot(xs, [r['floor'] for r in rs], color=C[k], lw=1, ls=':')
        ax.set_title(f'{mo.capitalize()} signing', fontsize=9)
        ax.set_xlabel('Number of RCAs $m$')
        ax.set_xticks(sorted({r['m'] for r in recs}))
        ax.set_ylim(0, ymax)
    axes[0][0].set_ylabel('Session establishment (ms)')
    h, l = axes[0][0].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=4, fontsize=7, bbox_to_anchor=(0.5, -0.04))
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    fig.savefig(os.path.join(F, f'fig_{name}_latency.pdf'), bbox_inches='tight')
    fig.savefig(os.path.join(F, f'fig_{name}_latency.png'), dpi=150, bbox_inches='tight')
    plt.close(fig)

    # ---------------- table rows
    rows = []
    for r in recs:
        rows.append('%s & %s & %d & %d & %.1f & [%.1f, %.1f] & %.0f & %.1f & %.1f \\\\' % (
            r['scenario'], r['mode'], r['m'], r['sessions'], r['lat_med'], r['lat_q1'], r['lat_q3'],
            r['floor'], r['lat_med'] - r['floor'], r['tsig_med']))
    open(os.path.join(T, f'{name}.tex'), 'w').write('\n'.join(rows) + '\n')
    json.dump(recs, open(os.path.join(D, 'results', f'{name}_summary.json'), 'w'), indent=1)
    bad = [r for r in recs if not r['keys_agreed']]
    print(f'{len(recs)} configurations loaded; delay methods: {sorted({r["delay"] for r in recs})}; '
          f'key agreement failures: {len(bad)}')
    for r in recs:
        print('%-3s %-10s m=%d  median %.1f ms  (network floor %.0f ms, overhead %.1f ms, tsig %.1f ms)' % (
            r['scenario'], r['mode'], r['m'], r['lat_med'], r['floor'], r['lat_med'] - r['floor'], r['tsig_med']))


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(D, 'testbed', 'run', 'results'),
         sys.argv[2] if len(sys.argv) > 2 else 'testbed')
