# Hybrid CA trust protocol: research prototype

Prototype, benchmarks and analysis scripts for the paper "A Cloud-Based Hybrid Certificate Authority Trust Model Integrating Threshold Signatures and Metadata-Bound Ephemeral Group Keys".

This is research code. It is not hardened for production use: it is not constant-time, it uses a trusted dealer, and it stores no keys securely.

## Files

| File | Purpose |
|---|---|
| `tcrypto.py` | Metadata encoding, SHA3-256 digests, Shoup threshold RSA (with correctness proofs, robust and optimistic combination), Burmester-Desmedt group key agreement (RFC 3526 2048-bit group), HKDF-SHA3-256 |
| `protocol.py` | Full session protocol among m Root CAs; running it executes the attack scenarios (MITM, metadata tampering, Byzantine node) |
| `test_tcrypto.py` | Correctness tests |
| `bench.py` | Benchmarks: `micro2048`, `micro3072`, `sessions`, `faults` |
| `analysis.py` | Builds the paper's figures (`figures/`) and table rows (`tables/`) from `results/*.json` |
| `toy.py` | Checked computation of the worked toy example in the appendix |
| `results/` | Raw benchmark results used in the paper |
| `HybridCA_Colab.ipynb` | Google Colab notebook: tests, benchmarks and networked testbed |
| `testbed/` | Networked testbed: `node.py` (signing node), `rca.py` (Root CA coordinator), `driver.py` (runs sessions, records results), `keygen.py`, `run_local.py` (processes on one machine), Docker files (`Dockerfile`, `entrypoint.sh`, `gen_compose.py`, `run_docker.sh`) |

## Requirements

Python 3.10+, `gmpy2`, `cryptography`, `matplotlib`, and the `openssl` command-line tool (used to generate safe primes).

```
pip install gmpy2 cryptography matplotlib
```

## Reproduce

```
python3 test_tcrypto.py      # correctness tests
python3 protocol.py          # session + attack scenarios
# generate safe primes for the benchmarks
mkdir -p params
for i in $(seq 1 24); do openssl prime -generate -bits 1024 -safe; done > params/p1024_pool.txt
openssl prime -generate -bits 1536 -safe > params/p1536a.txt
openssl prime -generate -bits 1536 -safe > params/p1536b.txt
taskset -c 1 python3 bench.py micro2048
taskset -c 1 python3 bench.py micro3072
taskset -c 1 python3 bench.py sessions
taskset -c 1 python3 bench.py faults
python3 analysis.py
```

`taskset` pins each run to one core and is optional, but it reduces timing noise. On a different machine the absolute times will differ.

## Networked testbed

The testbed runs the protocol over real TCP connections: each Root CA coordinator and each signing node is a separate process (or container). The driver starts sessions on all Root CAs at the same time and records end-to-end times, and it checks that all Root CAs derived the same key.

Network delay can be emulated in two ways:

* **netem** (Docker): `tc netem` delays packets in the Linux kernel on each container's network interface. This is the more realistic option, and the one to report in the paper.
* **app** (Colab, laptop): each process waits RTT/2 before sending a message. Use it where netem is unavailable.

If netem cannot be applied, the containers fall back to `app` automatically and print a warning. The result files record the delay method that was actually used (`DELAY_MODE_EFFECTIVE`).

### Option A: Docker (recommended)

You need Docker Desktop (Windows/macOS) or Docker Engine (Linux), and bash (on Windows use WSL). From this folder, run:

```
bash testbed/run_docker.sh
```

This builds the image, generates keys, and runs every combination of scenarios S1–S4, m = 2, 3, 5 Root CAs, and robust and optimistic modes. Each run starts m coordinators, m×5 nodes and a driver on three kinds of virtual networks (control, WAN, per-RCA LAN) and records 30 sessions. Results go to `testbed/run/results/*.json`. Environment variables let you change the defaults, for example:

```
SESSIONS=10 MS="3" SCENARIOS="S2:40:2" MODES="optimistic" bash testbed/run_docker.sh
```

Give Docker as many CPU cores as you can: Docker Desktop -> Settings -> Resources. Every container is limited to 1 CPU, so with few cores the nodes cannot compute in parallel and signing times rise.

To check that netem works, look for a line such as `netem: 20ms one-way on eth1` in the output (it is printed from rca0's log). If you see `WARNING: tc/netem unavailable`, that run used application-level delay instead.

### Option B: Google Colab

Open `HybridCA_Colab.ipynb` in Colab, run the first cell, upload this zip, and then run all cells. Colab cannot use netem, so the testbed runs with application-level delay.

### Option C: any computer with Python

```
python testbed/run_local.py --m 3 --t 3 --n 5 --inter-rtt 40 --intra-rtt 2 --sessions 20 --mode optimistic
```
