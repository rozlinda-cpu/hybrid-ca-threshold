"""Benchmarks for the hybrid CA protocol prototype. Writes JSON to results/."""
import json, os, sys, time, statistics, secrets, platform, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tcrypto as tc
import protocol as pr
from gmpy2 import mpz, powmod, invert
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

OUT = os.environ.get('BENCH_OUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results'))
os.makedirs(OUT, exist_ok=True)
PD = os.environ.get('BENCH_PARAMS', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'params'))


def load_pool():
    ps = [mpz(l.strip()) for l in open(os.path.join(PD, 'p1024_pool.txt')) if l.strip()]
    return [(ps[2 * i], ps[2 * i + 1]) for i in range(len(ps) // 2)]


def primes_3072():
    return (mpz(open(os.path.join(PD, 'p1536a.txt')).read().strip()),
            mpz(open(os.path.join(PD, 'p1536b.txt')).read().strip()))


def ms(xs):
    xs = [x * 1000 for x in xs]
    q = statistics.quantiles(xs, n=4) if len(xs) >= 4 else [min(xs), statistics.median(xs), max(xs)]
    return dict(median=statistics.median(xs), q1=q[0], q3=q[2], mean=statistics.mean(xs), n=len(xs))


def timeit(fn, reps, warmup=5):
    for _ in range(warmup):
        fn()
    out = []
    for _ in range(reps):
        a = time.perf_counter(); fn(); out.append(time.perf_counter() - a)
    return out


def e1_micro(bits, configs, reps, primes):
    reps = int(os.environ.get('BENCH_REPS', reps))
    res = []
    for (t, n) in configs:
        dt = []
        for _ in range(3):
            a = time.perf_counter(); pk, shares = tc.deal(bits, n, t, primes=primes); dt.append(time.perf_counter() - a)
        msg = secrets.token_bytes(64)
        S = shares[:t]
        p_np = timeit(lambda: tc.partial_sign(S[0], msg, with_proof=False), reps)
        p_wp = timeit(lambda: tc.partial_sign(S[0], msg, with_proof=True), reps)
        parts = [tc.partial_sign(s, msg) for s in S]
        vp = timeit(lambda: tc.verify_partial(pk, msg, parts[1]), reps)
        cb = timeit(lambda: tc.combine(pk, msg, parts), reps)
        y = tc.combine(pk, msg, parts)
        assert pk.verify(msg, y)
        vs = timeit(lambda: pk.verify(msg, y), reps)
        i, xi, (z, c) = parts[0]
        size_partial = (int(pk.N).bit_length() + 7) // 8 + (int(z).bit_length() + 7) // 8 + tc.L1 // 8 + 2
        r = dict(bits=bits, t=t, n=n, deal=ms(dt), partial_noproof=ms(p_np), partial_proof=ms(p_wp),
                 verify_partial=ms(vp), combine=ms(cb), verify_sig=ms(vs),
                 size_partial_bytes=size_partial, size_sig_bytes=(int(pk.N).bit_length() + 7) // 8,
                 delta_bits=int(pk.delta).bit_length())
        res.append(r)
        print(bits, t, n, 'partial+proof %.2f ms, verify_partial %.2f, combine %.2f' %
              (r['partial_proof']['median'], r['verify_partial']['median'], r['combine']['median']), flush=True)
    # baselines: centralised RSA signing on the same FDH message
    p, q = primes
    N = p * q; phi = (p - 1) * (q - 1); e = mpz(65537); d = invert(e, phi)
    dp, dq, qinv = d % (p - 1), d % (q - 1), invert(q, p)
    msg = secrets.token_bytes(64)
    def crt():
        x = tc.fdh(msg, N); m1 = powmod(x, dp, p); m2 = powmod(x, dq, q)
        return m2 + q * ((qinv * (m1 - m2)) % p)
    def nocrt():
        return powmod(tc.fdh(msg, N), d, N)
    key = rsa.generate_private_key(public_exponent=65537, key_size=bits)
    ossl = lambda: key.sign(msg, padding.PKCS1v15(), hashes.SHA256())
    base = dict(bits=bits, gmpy2_crt=ms(timeit(crt, reps)), gmpy2_nocrt=ms(timeit(nocrt, reps)),
                openssl_pkcs1=ms(timeit(ossl, reps)))
    return res, base


def e3_sessions(m_values, reps, pool, t=3, n=5, bits=2048):
    reps = int(os.environ.get('BENCH_SESSIONS', reps))
    res = []
    for m in m_values:
        rows = []
        for rep in range(reps):
            prs = [pool[(rep * 3 + i) % len(pool)] for i in range(m)]
            rcas = pr.make_rcas(m, bits, t, n, primes_pool=prs)
            ks = pr.run_session(rcas, policy_check=lambda md: md['version'] == 1)
            assert len(set(ks)) == 1
            for r in rcas:
                tm = r.timing
                rows.append(dict(
                    bd_compute=tm['r1'] + tm['r2_local'] + tm['key'],
                    tsig=tm['tsig_partial_max'] + tm['tsig_combine'],
                    verify=tm['verify_sigs'],
                    total=tm['r1'] + tm['r2_local'] + tm['tsig_partial_max'] + tm['tsig_combine'] + tm['verify_sigs'] + tm['key']))
        agg = {k: ms([r[k] for r in rows]) for k in rows[0]}
        r1_bytes = 2 + 16 + 16 + 256
        r2_bytes = 2 + 256 + 256
        agg.update(m=m, t=t, n=n, bits=bits, r1_msg_bytes=r1_bytes, r2_msg_bytes=r2_bytes,
                   bytes_sent_per_rca=(m - 1) * (r1_bytes + r2_bytes),
                   total_bytes_unicast=m * (m - 1) * (r1_bytes + r2_bytes))
        res.append(agg)
        print('m=%d total %.1f ms (tsig %.1f, verify %.1f, bd %.1f)' % (
            m, agg['total']['median'], agg['tsig']['median'], agg['verify']['median'], agg['bd_compute']['median']), flush=True)
    return res


def e4_faults(trials, primes, t=3, n=5, bits=2048):
    trials = int(os.environ.get('BENCH_TRIALS', trials))
    pk, shares = tc.deal(bits, n, t, primes=primes)
    out = []
    scen = [('crash', f) for f in range(0, n - t + 2)] + [('byzantine', b) for b in range(1, n - t + 2)]
    for kind, f in scen:
        succ, times, rej = 0, [], []
        for _ in range(trials):
            msg = secrets.token_bytes(32)
            bad = set(random.sample(range(1, n + 1), f))
            parts = []
            for s in shares:
                if s.i in bad:
                    if kind == 'crash':
                        continue
                    s = tc.KeyShare(s.i, s.s + secrets.randbelow(1000) + 1, pk)
                parts.append(tc.partial_sign(s, msg))
            # worst case ordering for Byzantine: faulty partials arrive first
            parts.sort(key=lambda p: 0 if p[0] in bad else 1)
            a = time.perf_counter()
            y, rejected = tc.robust_sign(pk, msg, parts)
            times.append(time.perf_counter() - a)
            if y is not None and pk.verify(msg, y):
                succ += 1
            rej.append(len(rejected))
        out.append(dict(kind=kind, faulty=f, success_rate=succ / trials, coordinator=ms(times),
                        mean_rejected=statistics.mean(rej), trials=trials))
        print(kind, f, 'success', succ / trials, '%.1f ms' % out[-1]['coordinator']['median'], flush=True)
    return out


if __name__ == '__main__':
    which = sys.argv[1]
    env = dict(python=platform.python_version(), machine=platform.machine(), processor=platform.processor(),
               cpus=os.cpu_count(), gmpy2=__import__('gmpy2').version(),
               cryptography=__import__('cryptography').__version__)
    pool = load_pool() if which != 'micro3072' else None
    if which == 'micro2048':
        res, base = e1_micro(2048, [(2, 3), (3, 5), (4, 7), (6, 10), (8, 15)], 80, pool[0])
        json.dump(dict(env=env, results=res, baseline=base), open(os.path.join(OUT, 'micro2048.json'), 'w'), indent=1)
    elif which == 'micro3072':
        res, base = e1_micro(3072, [(2, 3), (3, 5), (4, 7), (6, 10), (8, 15)], 100, primes_3072())
        json.dump(dict(env=env, results=res, baseline=base), open(os.path.join(OUT, 'micro3072.json'), 'w'), indent=1)
    elif which == 'sessions':
        pr.run_session(pr.make_rcas(2, 2048, 3, 5, primes_pool=pool[:2]))  # warm-up
        res = e3_sessions([2, 3, 4, 5, 6, 8, 10], 12, pool)
        json.dump(dict(env=env, results=res), open(os.path.join(OUT, 'sessions.json'), 'w'), indent=1)
    elif which == 'faults':
        res = e4_faults(100, pool[1])
        json.dump(dict(env=env, results=res), open(os.path.join(OUT, 'faults.json'), 'w'), indent=1)
