"""
Prototype of the hybrid CA trust protocol.

Components
  * Metadata encoding and SHA3-256 digests (per-RCA and composite).
  * Shoup's practical threshold RSA (EUROCRYPT 2000) with trusted dealer,
    including non-interactive proofs of partial-signature correctness.
  * Burmester-Desmedt (BD) two-round group key agreement over the RFC 3526
    2048-bit MODP group, authenticated by one threshold signature per RCA
    over its view of the transcript (nonces, round-1 values, own round-2 value,
    composite metadata digest).
  * Session key derivation with HKDF (RFC 5869) instantiated with SHA3-256.

This is research prototype code, not production code.
"""
import hashlib, hmac, os, secrets, struct, subprocess
from math import factorial, gcd
import gmpy2
from gmpy2 import mpz, powmod, invert

H = hashlib.sha3_256
L1 = 128  # bit length of challenge in correctness proofs


def i2b(x, nbytes=None):
    x = int(x)
    if nbytes is None:
        nbytes = max(1, (x.bit_length() + 7) // 8)
    return x.to_bytes(nbytes, 'big')


def b2i(b):
    return mpz(int.from_bytes(b, 'big'))


# --------------------------------------------------------------------------
# Metadata
# --------------------------------------------------------------------------
ALG_IDS = {'RSA': 0x00000001, 'ECDSA-P256': 0x00000002, 'Ed25519': 0x00000003,
           'ML-DSA-65': 0x00000004}


def encode_metadata(alg, keylen, version, timestamp, t, n):
    """128-bit metadata M = AlgID(32) || KeyL(16) || Ver(16) || TS(32) || t(16) || n(16)."""
    return struct.pack('>IHHIHH', ALG_IDS[alg], keylen, version, timestamp, t, n)


def decode_metadata(m):
    a, kl, v, ts, t, n = struct.unpack('>IHHIHH', m)
    inv = {v_: k for k, v_ in ALG_IDS.items()}
    return dict(alg=inv[a], keylen=kl, version=v, timestamp=ts, t=t, n=n)


def digest(m):
    return H(m).digest()


def composite_digest(digests):
    """h_X = SHA3-256 over the lexicographically sorted per-RCA digests (order independent)."""
    return H(b''.join(sorted(digests))).digest()


# --------------------------------------------------------------------------
# HKDF with SHA3-256 (RFC 5869)
# --------------------------------------------------------------------------
def hkdf(ikm, salt, info, length=32):
    prk = hmac.new(salt, ikm, H).digest()
    out, t, i = b'', b'', 1
    while len(out) < length:
        t = hmac.new(prk, t + info + bytes([i]), H).digest()
        out += t
        i += 1
    return out[:length]


# --------------------------------------------------------------------------
# Full-domain hash into Z_N (MGF1-style expansion with SHA3-256)
# --------------------------------------------------------------------------
def fdh(msg, N):
    nbytes = (int(N).bit_length() + 7) // 8 + 16
    out, c = b'', 0
    while len(out) < nbytes:
        out += H(msg + struct.pack('>I', c)).digest()
        c += 1
    return b2i(out[:nbytes]) % N


# --------------------------------------------------------------------------
# Shoup threshold RSA
# --------------------------------------------------------------------------
def safe_prime(bits):
    out = subprocess.run(['openssl', 'prime', '-generate', '-bits', str(bits), '-safe'],
                         capture_output=True, text=True, check=True).stdout.strip()
    return mpz(out)


class PublicKey:
    def __init__(self, N, e, n, t, v, vks):
        self.N, self.e, self.n, self.t, self.v, self.vks = N, e, n, t, v, vks
        self.delta = mpz(factorial(n))

    def verify(self, msg, y):
        return powmod(y, self.e, self.N) == fdh(msg, self.N)


class KeyShare:
    def __init__(self, index, s, pk):
        self.i, self.s, self.pk = index, s, pk


def deal(bits, n, t, e=65537, primes=None):
    """Trusted dealer key generation. Returns (PublicKey, [KeyShare], timing-free)."""
    assert 1 <= t <= n and e > n
    if primes is None:
        p, q = safe_prime(bits // 2), safe_prime(bits // 2)
    else:
        p, q = primes
    N = p * q
    pp, qq = (p - 1) // 2, (q - 1) // 2
    m = pp * qq
    d = invert(mpz(e), m)
    coeffs = [d] + [mpz(secrets.randbelow(int(m))) for _ in range(t - 1)]

    def f(x):
        acc = mpz(0)
        for c in reversed(coeffs):
            acc = (acc * x + c) % m
        return acc
    shares = [f(i) for i in range(1, n + 1)]
    # random generator of Q_N (square of a random unit)
    while True:
        r = mpz(secrets.randbelow(int(N) - 2) + 2)
        if gcd(int(r), int(N)) == 1:
            break
    v = powmod(r, 2, N)
    vks = [powmod(v, s, N) for s in shares]
    pk = PublicKey(N, mpz(e), n, t, v, vks)
    return pk, [KeyShare(i + 1, shares[i], pk) for i in range(n)]


def _challenge(*vals):
    h = H(b'|'.join(i2b(x) for x in vals)).digest()
    return b2i(h) >> (256 - L1)


def partial_sign(share, msg, with_proof=True):
    pk = share.pk
    N, delta = pk.N, pk.delta
    x = fdh(msg, N)
    xi = powmod(x, 2 * delta * share.s, N)
    if not with_proof:
        return (share.i, xi, None)
    xt = powmod(x, 4 * delta, N)
    r = mpz(secrets.randbits(int(N).bit_length() + 2 * L1))
    v1, x1 = powmod(pk.v, r, N), powmod(xt, r, N)
    c = _challenge(pk.v, xt, pk.vks[share.i - 1], powmod(xi, 2, N), v1, x1)
    z = share.s * c + r
    return (share.i, xi, (z, c))


def verify_partial(pk, msg, part):
    i, xi, proof = part
    N = pk.N
    z, c = proof
    x = fdh(msg, N)
    xt = powmod(x, 4 * pk.delta, N)
    vi = pk.vks[i - 1]
    v1 = powmod(pk.v, z, N) * powmod(invert(vi, N), c, N) % N
    x1 = powmod(xt, z, N) * powmod(invert(xi, N), 2 * c, N) % N
    return c == _challenge(pk.v, xt, vi, powmod(xi, 2, N), v1, x1)


def _lambda(delta, S, j):
    num, den = mpz(1), mpz(1)
    for jp in S:
        if jp != j:
            num *= -jp
            den *= (j - jp)
    val = delta * num
    assert val % den == 0
    return val // den


def combine(pk, msg, parts):
    """Combine t valid partial signatures into a standard RSA signature y with y^e = H(msg)."""
    N, e, delta = pk.N, pk.e, pk.delta
    parts = parts[:pk.t]
    S = [p[0] for p in parts]
    w = mpz(1)
    for (j, xj, _) in parts:
        lam = _lambda(delta, S, j)
        base = xj if lam >= 0 else invert(xj, N)
        w = w * powmod(base, 2 * abs(lam), N) % N
    ep = 4 * delta * delta
    g, a, b = gmpy2.gcdext(ep, e)
    assert g == 1
    x = fdh(msg, N)
    wa = powmod(w if a >= 0 else invert(w, N), abs(a), N)
    xb = powmod(x if b >= 0 else invert(x, N), abs(b), N)
    return wa * xb % N


def robust_sign(pk, msg, parts):
    """Verify proofs, drop invalid partials, combine first t valid ones. Returns (sig, rejected_ids)."""
    good, bad = [], []
    for p in parts:
        (good if verify_partial(pk, msg, p) else bad).append(p)
        if len(good) == pk.t:
            break
    if len(good) < pk.t:
        return None, [p[0] for p in bad]
    return combine(pk, msg, good), [p[0] for p in bad]


# --------------------------------------------------------------------------
# Burmester-Desmedt group key agreement over RFC 3526 group 14 (2048-bit MODP)
# --------------------------------------------------------------------------
P2048 = mpz(int(
    "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DD"
    "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
    "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F"
    "83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
    "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA0510"
    "15728E5A8AACAA68FFFFFFFFFFFFFFFF", 16))
G = mpz(2)
Q2048 = (P2048 - 1) // 2
EXP_BITS = 256  # short exponents (~128-bit security level of the 2048-bit group is ~112 bits)


class BDParty:
    def __init__(self, idx, m, p=P2048, g=G):
        self.idx, self.m, self.p, self.g = idx, m, p, g
        self.r = mpz(secrets.randbits(EXP_BITS))
        self.nonce = os.urandom(16)

    def round1(self):
        self.z = powmod(self.g, self.r, self.p)
        return self.z

    def round2(self, zs):
        m, i, p = self.m, self.idx, self.p
        self.zs = zs
        zn, zp = zs[(i + 1) % m], zs[(i - 1) % m]
        self.X = powmod(zn * invert(zp, p) % p, self.r, p)
        return self.X

    def key(self, Xs):
        m, i, p = self.m, self.idx, self.p
        K = powmod(self.zs[(i - 1) % m], m * self.r, p)
        for k in range(m - 1):
            K = K * powmod(Xs[(i + k) % m], m - 1 - k, p) % p
        return K


def transcript_r2(sid, hX, zs, idx, X):
    """Bytes signed by RCA idx in round 2: its view of round 1 plus its own round-2 value."""
    zb = b''.join(i2b(z, 256) for z in zs)
    return b'R2|' + sid + b'|' + hX + b'|' + zb + b'|' + struct.pack('>H', idx) + b'|' + i2b(X, 256)


def session_key(K, hX, sid, zs, Xs):
    info = b'hybrid-ca-session|' + sid + b'|' + H(b''.join(i2b(z, 256) for z in zs) +
                                                   b''.join(i2b(x, 256) for x in Xs)).digest()
    return hkdf(i2b(K, 256), salt=hX, info=info, length=32)
