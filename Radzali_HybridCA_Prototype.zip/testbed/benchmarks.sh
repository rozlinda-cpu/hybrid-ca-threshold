#!/usr/bin/env bash
# Runs the computation benchmarks (Tables 5-7 and 9, Figs. 4-6) inside Docker on this computer,
# records the hardware, and saves bench_results.zip next to the .bat files. About 20-40 minutes.
cd "$(dirname "$0")/.."
if ! docker info >/dev/null 2>&1; then
  echo "ERROR: Docker is not running or not connected to Ubuntu."
  echo "Open Docker Desktop, wait for 'Engine running', check Settings > Resources > WSL integration > Ubuntu is ON, then try again."
  exit 1
fi
IMAGE=${IMAGE:-hybridca-testbed}
if [ "${SKIP_BUILD:-0}" != "1" ]; then
  docker build -q -t "$IMAGE" -f testbed/Dockerfile . || exit 1
fi
mkdir -p bench_out/results bench_out/params
{ echo "== lscpu =="; lscpu; echo; echo "== nproc =="; nproc; echo; echo "== memory =="; free -h; echo; echo "== OS =="; uname -a; cat /etc/os-release 2>/dev/null | head -2; echo; echo "== Docker =="; docker version --format 'Client {{.Client.Version}} / Server {{.Server.Version}}'; docker info --format 'Docker CPUs: {{.NCPU}}  Memory: {{.MemTotal}}'; } > bench_out/hardware.txt 2>&1
echo "Hardware recorded:"; grep -E 'Model name|^CPU\(s\)|Mem:' bench_out/hardware.txt
CPU=1; [ "$(nproc)" -lt 2 ] && CPU=0
run() {
  docker run --rm --cpuset-cpus="$CPU" --entrypoint sh -v "$PWD:/work" -w /work \
    -e BENCH_OUT=/work/bench_out/results -e BENCH_PARAMS=/work/bench_out/params ${BENCH_REPS:+-e BENCH_REPS=$BENCH_REPS} ${BENCH_SESSIONS:+-e BENCH_SESSIONS=$BENCH_SESSIONS} ${BENCH_TRIALS:+-e BENCH_TRIALS=$BENCH_TRIALS} "$IMAGE" -c "$1"
}
echo; echo "[1/5] Generating safe primes (a few minutes)..."
run 'i=0; while [ $i -lt 24 ]; do openssl prime -generate -bits 1024 -safe || exit 1; i=$((i+1)); done > bench_out/params/p1024_pool.txt' || exit 1
run 'openssl prime -generate -bits 1536 -safe > bench_out/params/p1536a.txt' || exit 1
run 'openssl prime -generate -bits 1536 -safe > bench_out/params/p1536b.txt' || exit 1
echo "[2/5] Threshold RSA, 2048 bits..."; run 'python bench.py micro2048' || exit 1
echo "[3/5] Threshold RSA, 3072 bits..."; run 'python bench.py micro3072' || exit 1
echo "[4/5] Session establishment, 2-10 Root CAs..."; run 'python bench.py sessions' || exit 1
echo "[5/5] Fault injection..."; run 'python bench.py faults' || exit 1
python3 - <<'PY'
import zipfile, glob
with zipfile.ZipFile('bench_results.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in glob.glob('bench_out/results/*.json') + ['bench_out/hardware.txt']:
        z.write(f)
print('\nSaved: bench_results.zip  (send this file)')
PY
