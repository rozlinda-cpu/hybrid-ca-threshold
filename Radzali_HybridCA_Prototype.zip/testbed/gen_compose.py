"""Writes a docker-compose.yml for m RCAs with n nodes each (prints to stdout).

Networks: ctl (driver control, no delay), wan (between RCA coordinators, delay = inter RTT),
lan_k (inside RCA k, delay = intra RTT). One-way delay = RTT/2 is applied on each side.
"""
import argparse


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--m', type=int, default=3)
    ap.add_argument('--n', type=int, default=5)
    ap.add_argument('--inter-rtt', type=float, default=0)
    ap.add_argument('--intra-rtt', type=float, default=0)
    ap.add_argument('--mode', default='robust')
    ap.add_argument('--byzantine', type=int, default=0)
    ap.add_argument('--sessions', type=int, default=30)
    ap.add_argument('--label', default='docker')
    ap.add_argument('--delay-mode', default='netem', choices=['netem', 'app'])
    ap.add_argument('--image', default='hybridca-testbed')
    ap.add_argument('--cpus', default='1.0', help='CPU limit per container')
    a = ap.parse_args()
    inter1, intra1 = a.inter_rtt / 2, a.intra_rtt / 2
    L = ['services:']

    def common(env, nets, cmd, extra=''):
        out = [f'    image: {a.image}', '    cap_add: [NET_ADMIN]', f'    cpus: {a.cpus}',
               '    volumes: ["./data:/data:ro"]', '    environment:']
        for k, v in env.items():
            out.append(f'      {k}: "{v}"')
        out.append('    networks:')
        for net, ip in nets:
            out.append(f'      {net}: {{ipv4_address: {ip}}}')
        out.append('    command: ' + cmd)
        return out + ([extra] if extra else [])

    base_env = dict(DELAY_MODE=a.delay_mode, INTER_ONEWAY_MS=inter1, INTRA_ONEWAY_MS=intra1,
                    INTER_RTT_MS=a.inter_rtt, INTRA_RTT_MS=a.intra_rtt)
    for k in range(a.m):
        for i in range(1, a.n + 1):
            env = dict(base_env, LAN_PREFIX=f'172.30.{k}.')
            cmd = f'["python", "/app/testbed/node.py", "--keyfile", "/data/rca{k}/node{i}.json", "--port", "7000"'
            cmd += ', "--byzantine"]' if i <= a.byzantine else ']'
            L.append(f'  node{k}_{i}:')
            L += common(env, [(f'lan{k}', f'172.30.{k}.{10 + i}')], cmd)
        peers = ','.join(f'{j}:172.29.0.{10 + j}:6000' for j in range(a.m) if j != k)
        nodes = ','.join(f'{i}:172.30.{k}.{10 + i}:7000' for i in range(1, a.n + 1))
        env = dict(base_env, WAN_PREFIX='172.29.0.', LAN_PREFIX=f'172.30.{k}.')
        cmd = (f'["python", "/app/testbed/rca.py", "--k", "{k}", "--data", "/data", "--port", "6000", '
               f'"--peers", "{peers}", "--nodes", "{nodes}", "--mode", "{a.mode}"]')
        L.append(f'  rca{k}:')
        L += common(env, [('ctl', f'172.28.0.{10 + k}'), ('wan', f'172.29.0.{10 + k}'), (f'lan{k}', f'172.30.{k}.2')], cmd,
                     '    depends_on: [' + ', '.join(f'node{k}_{i}' for i in range(1, a.n + 1)) + ']')
    rcas = ','.join(f'{k}:172.28.0.{10 + k}:6000' for k in range(a.m))
    L.append('  driver:')
    L += [f'    image: {a.image}', '    profiles: ["driver"]', '    volumes: ["./results:/results"]',
          '    environment:', f'      DELAY_MODE: "{a.delay_mode}"', f'      INTER_RTT_MS: "{a.inter_rtt}"',
          f'      INTRA_RTT_MS: "{a.intra_rtt}"', '    networks:', '      ctl: {ipv4_address: 172.28.0.2}',
          f'    command: ["python", "/app/testbed/driver.py", "--rcas", "{rcas}", "--sessions", "{a.sessions}", '
          f'"--label", "{a.label}", "--out", "/results"]']
    L.append('networks:')
    L += ['  ctl:', '    ipam: {config: [{subnet: 172.28.0.0/24}]}', '  wan:', '    ipam: {config: [{subnet: 172.29.0.0/24}]}']
    for k in range(a.m):
        L += [f'  lan{k}:', f'    ipam: {{config: [{{subnet: 172.30.{k}.0/24}}]}}']
    print('\n'.join(L))


if __name__ == '__main__':
    main()
