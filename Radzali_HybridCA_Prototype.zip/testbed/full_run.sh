#!/usr/bin/env bash
# Full experiment (about 30-60 minutes). Saves docker_results.zip next to the .bat files.
cd "$(dirname "$0")/.."
if ! docker info >/dev/null 2>&1; then
  echo "ERROR: Docker is not running or not connected to Ubuntu."
  echo "Open Docker Desktop, wait for 'Engine running', check Settings > Resources > WSL integration > Ubuntu is ON, then try again."
  exit 1
fi
bash testbed/run_docker.sh 2>&1 | grep --line-buffered -v -E '^\s*(Container|Network) ' | tee full_run_log.txt
if ! ls testbed/run/results/*.json >/dev/null 2>&1; then echo 'No results were produced - send a screenshot of this window.'; exit 1; fi
python3 - <<'PY'
import zipfile, glob, os
with zipfile.ZipFile('docker_results.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in glob.glob('testbed/run/results/*.json') + ['full_run_log.txt']:
        if os.path.exists(f):
            z.write(f)
print('\nSaved: docker_results.zip  (send this file)')
PY
