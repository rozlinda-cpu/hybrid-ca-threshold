"""Run the whole testbed as local processes (laptop, Colab). Network delay is emulated in the
application (one-way delay = RTT/2 before each send), because tc/netem is usually unavailable there.

Example:
  python run_local.py --m 3 --t 3 --n 5 --inter-rtt 40 --intra-rtt 2 --sessions 20 --label S2_m3
"""
import argparse, os, subprocess, sys, time, signal

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--m', type=int, default=3)
    ap.add_argument('--t', type=int, default=3)
    ap.add_argument('--n', type=int, default=5)
    ap.add_argument('--bits', type=int, default=2048)
    ap.add_argument('--inter-rtt', type=float, default=0)
    ap.add_argument('--intra-rtt', type=float, default=0)
    ap.add_argument('--sessions', type=int, default=20)
    ap.add_argument('--mode', choices=['robust', 'optimistic'], default='robust')
    ap.add_argument('--byzantine', type=int, default=0, help='number of Byzantine nodes per RCA')
    ap.add_argument('--data', default=os.path.join(HERE, 'data'))
    ap.add_argument('--out', default=os.path.join(HERE, 'results'))
    ap.add_argument('--label', default=None)
    ap.add_argument('--reuse-keys', action='store_true')
    a = ap.parse_args()
    label = a.label or f'local_m{a.m}_t{a.t}n{a.n}_inter{a.inter_rtt:g}_intra{a.intra_rtt:g}_{a.mode}'
    py = sys.executable
    if not (a.reuse_keys and os.path.exists(os.path.join(a.data, 'config.json'))):
        subprocess.run([py, os.path.join(HERE, 'keygen.py'), '--m', str(a.m), '--t', str(a.t), '--n', str(a.n),
                        '--bits', str(a.bits), '--out', a.data], check=True)
    env = dict(os.environ, DELAY_MODE='app', INTER_ONEWAY_MS=str(a.inter_rtt / 2), INTRA_ONEWAY_MS=str(a.intra_rtt / 2),
               INTER_RTT_MS=str(a.inter_rtt), INTRA_RTT_MS=str(a.intra_rtt))
    procs = []
    base = 20000
    rca_port = {k: base + k for k in range(a.m)}
    try:
        for k in range(a.m):
            for i in range(1, a.n + 1):
                cmd = [py, os.path.join(HERE, 'node.py'), '--keyfile', os.path.join(a.data, f'rca{k}', f'node{i}.json'),
                       '--port', str(base + 1000 + 100 * k + i)]
                if i <= a.byzantine:
                    cmd.append('--byzantine')
                procs.append(subprocess.Popen(cmd, env=env, stdout=subprocess.DEVNULL))
        for k in range(a.m):
            peers = ','.join(f'{j}:127.0.0.1:{rca_port[j]}' for j in range(a.m) if j != k)
            nodes = ','.join(f'{i}:127.0.0.1:{base + 1000 + 100 * k + i}' for i in range(1, a.n + 1))
            procs.append(subprocess.Popen([py, os.path.join(HERE, 'rca.py'), '--k', str(k), '--data', a.data,
                                           '--port', str(rca_port[k]), '--peers', peers, '--nodes', nodes,
                                           '--mode', a.mode], env=env, stdout=subprocess.DEVNULL))
        time.sleep(2)
        rcas = ','.join(f'{k}:127.0.0.1:{rca_port[k]}' for k in range(a.m))
        subprocess.run([py, os.path.join(HERE, 'driver.py'), '--rcas', rcas, '--sessions', str(a.sessions),
                        '--label', label, '--out', a.out], env=env, check=True)
    finally:
        for p in procs:
            p.send_signal(signal.SIGTERM)
        for p in procs:
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()


if __name__ == '__main__':
    main()
