"""Trusted-dealer key generation for all RCAs of an experiment. Writes JSON key material to --out."""
import argparse, json, os, sys, shutil, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import gmpy2
from gmpy2 import mpz
import tcrypto as tc
from netcommon import enc

ALGS = ['RSA', 'ECDSA-P256', 'ECDSA-P256', 'Ed25519']


def safe_prime(bits):
    if shutil.which('openssl'):
        return tc.safe_prime(bits)
    # fallback: pure gmpy2 search (slower)
    rs = gmpy2.random_state(int.from_bytes(os.urandom(8), 'big'))
    while True:
        q = gmpy2.next_prime(gmpy2.mpz_urandomb(rs, bits - 1) | (mpz(1) << (bits - 2)))
        p = 2 * q + 1
        if gmpy2.is_prime(p, 40):
            return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--m', type=int, default=3)
    ap.add_argument('--t', type=int, default=3)
    ap.add_argument('--n', type=int, default=5)
    ap.add_argument('--bits', type=int, default=2048)
    ap.add_argument('--out', default='data')
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    meta = {}
    for k in range(a.m):
        p, q = safe_prime(a.bits // 2), safe_prime(a.bits // 2)
        pk, shares = tc.deal(a.bits, a.n, a.t, primes=(p, q))
        d = os.path.join(a.out, f'rca{k}')
        os.makedirs(d, exist_ok=True)
        pub = dict(N=pk.N, e=pk.e, n=pk.n, t=pk.t, v=pk.v, vks=pk.vks)
        open(os.path.join(d, 'pub.json'), 'wb').write(enc(pub))
        for s in shares:
            open(os.path.join(d, f'node{s.i}.json'), 'wb').write(enc(dict(i=s.i, s=s.s, **pub)))
        alg = ALGS[k % len(ALGS)]
        meta[k] = tc.encode_metadata(alg, a.bits if alg == 'RSA' else 256, 1, 1759017600, a.t, a.n).hex()
        print(f'RCA {k}: key generated', flush=True)
    json.dump(dict(m=a.m, t=a.t, n=a.n, bits=a.bits, metadata=meta), open(os.path.join(a.out, 'config.json'), 'w'))


if __name__ == '__main__':
    main()
