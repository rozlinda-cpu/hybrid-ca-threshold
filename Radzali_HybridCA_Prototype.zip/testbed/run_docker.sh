#!/usr/bin/env bash
# Runs the network-emulation experiments with Docker Compose.
# Requirements: Docker (Docker Desktop on Windows/macOS, or Docker Engine on Linux) and bash
# (on Windows use WSL or Git Bash). Run from the folder that contains tcrypto.py and testbed/.
#
#   bash testbed/run_docker.sh            # all scenarios
#   SESSIONS=10 bash testbed/run_docker.sh
set -euo pipefail
cd "$(dirname "$0")/.."
IMAGE=${IMAGE:-hybridca-testbed}
SESSIONS=${SESSIONS:-30}
T=${T:-3}; N=${N:-5}
DELAY_MODE=${DELAY_MODE:-netem}
MS=${MS:-"2 3 5"}            # numbers of RCAs to test
MODES=${MODES:-"robust optimistic"}
# scenario name : inter-RCA RTT (ms) : intra-RCA RTT (ms)
SCENARIOS=${SCENARIOS:-"S1:2:1 S2:40:2 S3:150:2 S4:150:40"}

if [ "${SKIP_BUILD:-0}" != "1" ]; then
  docker build -t "$IMAGE" -f testbed/Dockerfile .
fi
mkdir -p testbed/run/results
cd testbed/run

for M in $MS; do
  rm -rf data && mkdir -p data
  docker run --rm --entrypoint python -v "$PWD/data:/data" "$IMAGE" /app/testbed/keygen.py \
      --m "$M" --t "$T" --n "$N" --out /data
  for MODE in $MODES; do
    for SC in $SCENARIOS; do
      IFS=: read -r NAME INTER INTRA <<< "$SC"
      LABEL="docker_${NAME}_m${M}_t${T}n${N}_${MODE}"
      echo "=== $LABEL (inter ${INTER} ms, intra ${INTRA} ms, $DELAY_MODE) ==="
      docker run --rm --entrypoint python "$IMAGE" /app/testbed/gen_compose.py --m "$M" --n "$N" \
          --inter-rtt "$INTER" --intra-rtt "$INTRA" --mode "$MODE" --sessions "$SESSIONS" \
          --label "$LABEL" --delay-mode "$DELAY_MODE" --image "$IMAGE" > docker-compose.yml
      docker compose -p hybridca up -d --quiet-pull
      sleep 3
      docker compose -p hybridca logs rca0 | grep -E "netem|WARNING" | head -3 || true
      docker compose -p hybridca run --rm driver
      docker compose -p hybridca down -t 2
    done
  done
done
echo "Results written to testbed/run/results/"
