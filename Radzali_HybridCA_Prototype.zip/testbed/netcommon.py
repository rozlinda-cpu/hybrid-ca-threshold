"""Shared helpers for the networked testbed: framing, JSON with big integers, optional app-level delay."""
import asyncio, json, os, struct


def enc(obj):
    def conv(o):
        if isinstance(o, dict):
            return {k: conv(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [conv(v) for v in o]
        if type(o).__name__ == 'mpz' or (isinstance(o, int) and not isinstance(o, bool) and abs(o) > 2**53):
            return {'$i': hex(int(o))}
        if isinstance(o, bytes):
            return {'$b': o.hex()}
        return o
    return json.dumps(conv(obj)).encode()


def dec(b):
    from gmpy2 import mpz
    def conv(o):
        if isinstance(o, dict):
            if '$i' in o:
                return mpz(int(o['$i'], 16))
            if '$b' in o:
                return bytes.fromhex(o['$b'])
            return {k: conv(v) for k, v in o.items()}
        if isinstance(o, list):
            return [conv(v) for v in o]
        return o
    return conv(json.loads(b))


async def send(writer, obj, delay_ms=0.0):
    """Send one framed message. delay_ms > 0 emulates one-way link delay in the application
    (used when tc/netem is unavailable, e.g. on Colab)."""
    data = enc(obj)
    if delay_ms > 0:
        await asyncio.sleep(delay_ms / 1000.0)
    writer.write(struct.pack('>I', len(data)) + data)
    await writer.drain()


async def recv(reader):
    hdr = await reader.readexactly(4)
    (ln,) = struct.unpack('>I', hdr)
    return dec(await reader.readexactly(ln))


def env_delay(name):
    """One-way application-level delay in ms; 0 when netem is applied at the network layer."""
    if os.environ.get('DELAY_MODE', 'app') == 'netem':
        return 0.0
    return float(os.environ.get(name, '0'))
