"""Root CA coordinator: runs the metadata-bound authenticated group key agreement with peer RCAs
and obtains threshold signatures from its own signing nodes over TCP."""
import argparse, asyncio, hashlib, json, os, sys, time, itertools
from collections import defaultdict
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import tcrypto as tc
from netcommon import send, recv, dec, env_delay


def load_pub(path):
    d = dec(open(path, 'rb').read())
    return tc.PublicKey(d['N'], d['e'], d['n'], d['t'], d['v'], d['vks'])


def parse_addrs(s):
    out = {}
    for item in filter(None, s.split(',')):
        k, host, port = item.split(':')
        out[int(k)] = (host, int(port))
    return out


class RCA:
    def __init__(self, a):
        self.k = a.k
        self.cfg = json.load(open(os.path.join(a.data, 'config.json')))
        self.M = bytes.fromhex(self.cfg['metadata'][str(self.k)])
        self.pks = {j: load_pub(os.path.join(a.data, f'rca{j}', 'pub.json')) for j in range(self.cfg['m'])}
        self.pk = self.pks[self.k]
        self.peers = parse_addrs(a.peers)
        self.nodes = parse_addrs(a.nodes)
        self.mode = a.mode
        self.d_inter = env_delay('INTER_ONEWAY_MS')
        self.d_intra = env_delay('INTRA_ONEWAY_MS')
        self.peer_w = {}
        self.node_w = {}
        self.mail = defaultdict(asyncio.Queue)      # (session, round) -> queue of messages
        self.node_q = defaultdict(asyncio.Queue)    # rid -> queue of partials
        self.rid = itertools.count()

    # ------------------------------------------------------------- connections
    async def prepare(self):
        for j, (h, p) in self.peers.items():
            if j not in self.peer_w:
                _, w = await asyncio.open_connection(h, p)
                self.peer_w[j] = w
        for i, (h, p) in self.nodes.items():
            if i not in self.node_w:
                r, w = await asyncio.open_connection(h, p)
                self.node_w[i] = w
                asyncio.create_task(self.node_reader(r))

    async def node_reader(self, r):
        try:
            while True:
                msg = await recv(r)
                await self.node_q[msg['rid']].put(msg)
        except (asyncio.IncompleteReadError, ConnectionError):
            pass

    async def handle(self, r, w):
        try:
            while True:
                msg = await recv(r)
                op = msg.get('op')
                if op in ('R1', 'R2'):
                    await self.mail[(msg['sess'], op)].put(msg)
                elif op == 'prepare':
                    await self.prepare()
                    await send(w, dict(op='ready', k=self.k))
                elif op == 'start':
                    res = await self.session(msg['sess'], msg['participants'])
                    await send(w, res)
        except (asyncio.IncompleteReadError, ConnectionError):
            pass

    async def broadcast(self, participants, obj):
        await asyncio.gather(*[send(self.peer_w[j], obj, self.d_inter) for j in participants if j != self.k])

    async def gather_round(self, sess, rnd, participants):
        q = self.mail[(sess, rnd)]
        got = {}
        while len(got) < len(participants) - 1:
            m = await q.get()
            got[m['id']] = m
        del self.mail[(sess, rnd)]
        return got

    # ------------------------------------------------------------- threshold signing
    async def tsign(self, msg):
        comp = 0.0
        async def request(proof):
            rid = next(self.rid)
            await asyncio.gather(*[send(w, dict(op='sign', rid=rid, msg=msg, proof=proof), self.d_intra)
                                   for w in self.node_w.values()])
            return rid
        t = self.pk.t
        if self.mode == 'optimistic':
            rid = await request(False)
            parts = []
            while len(parts) < t:
                m = await self.node_q[rid].get()
                parts.append((m['i'], m['xi'], None))
            a = time.perf_counter()
            y = tc.combine(self.pk, msg, parts)
            ok = self.pk.verify(msg, y)
            comp += time.perf_counter() - a
            if ok:
                return y, comp, []
        rid = await request(True)              # robust mode (or fallback)
        good, bad = [], []
        while len(good) < t:
            m = await self.node_q[rid].get()
            p = (m['i'], m['xi'], (m['z'], m['c']))
            a = time.perf_counter()
            ok = tc.verify_partial(self.pk, msg, p)
            comp += time.perf_counter() - a
            (good if ok else bad).append(p)
            if len(bad) > self.pk.n - t:
                raise RuntimeError('too many invalid partial signatures')
        a = time.perf_counter()
        y = tc.combine(self.pk, msg, good)
        comp += time.perf_counter() - a
        return y, comp, [p[0] for p in bad]

    # ------------------------------------------------------------- session
    async def session(self, sess, participants):
        participants = sorted(participants)
        m = len(participants)
        idx = participants.index(self.k)
        T0 = time.perf_counter()
        comp = 0.0
        a = time.perf_counter()
        bd = tc.BDParty(idx, m)
        z = bd.round1()
        comp += time.perf_counter() - a
        await self.broadcast(participants, dict(op='R1', sess=sess, id=self.k, nonce=bd.nonce, M=self.M, z=z))
        r1 = await self.gather_round(sess, 'R1', participants)
        T1 = time.perf_counter()
        a = time.perf_counter()
        view = {self.k: dict(nonce=bd.nonce, M=self.M, z=z), **{j: r1[j] for j in r1}}
        for j in participants:
            md = tc.decode_metadata(view[j]['M'])
            if md['version'] != 1 or md['t'] < 2:
                raise ValueError('policy mismatch')
        sid = hashlib.sha3_256(b''.join(view[j]['nonce'] for j in participants)).digest()
        hX = tc.composite_digest([tc.digest(view[j]['M']) for j in participants])
        zs = [view[j]['z'] for j in participants]
        X = bd.round2(zs)
        tr = tc.transcript_r2(sid, hX, zs, idx, X)
        comp += time.perf_counter() - a
        a = time.perf_counter()
        sig, ccomp, rejected = await self.tsign(tr)
        tsig_ms = (time.perf_counter() - a) * 1000
        comp += ccomp
        await self.broadcast(participants, dict(op='R2', sess=sess, id=self.k, X=X, sig=sig))
        r2 = await self.gather_round(sess, 'R2', participants)
        a = time.perf_counter()
        Xs = []
        for pos, j in enumerate(participants):
            if j == self.k:
                Xs.append(X)
                continue
            trj = tc.transcript_r2(sid, hX, zs, pos, r2[j]['X'])
            if not self.pks[j].verify(trj, r2[j]['sig']):
                raise ValueError(f'authentication failure for RCA {j}')
            Xs.append(r2[j]['X'])
        K = bd.key(Xs)
        ks = tc.session_key(K, hX, sid, zs, Xs)
        comp += time.perf_counter() - a
        T2 = time.perf_counter()
        return dict(op='done', k=self.k, sess=sess, total_ms=(T2 - T0) * 1000, r1_wait_ms=(T1 - T0) * 1000,
                    tsig_ms=tsig_ms, compute_ms=comp * 1000, rejected=rejected,
                    delay_mode=os.environ.get('DELAY_MODE', 'app'),
                    key_hash=hashlib.sha3_256(ks).hexdigest()[:16])


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--k', type=int, required=True)
    ap.add_argument('--data', default='data')
    ap.add_argument('--port', type=int, required=True)
    ap.add_argument('--peers', required=True, help='k:host:port,... of the other RCAs')
    ap.add_argument('--nodes', required=True, help='i:host:port,... of this RCA\'s nodes')
    ap.add_argument('--mode', choices=['robust', 'optimistic'], default='robust')
    a = ap.parse_args()
    rca = RCA(a)
    srv = await asyncio.start_server(rca.handle, '0.0.0.0', a.port)
    print(f'RCA {a.k} listening on {a.port}', flush=True)
    async with srv:
        await srv.serve_forever()


if __name__ == '__main__':
    asyncio.run(main())
