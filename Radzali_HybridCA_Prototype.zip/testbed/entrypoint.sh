#!/bin/sh
# Applies one-way network delay with tc/netem on the container's WAN and LAN interfaces.
# If netem is not available, falls back to application-level delay (DELAY_MODE=app).

apply_delay() {
  prefix="$1"; delay="$2"
  [ -z "$prefix" ] && return 0
  [ -z "$delay" ] && return 0
  [ "$delay" = "0" ] && return 0
  dev=$(ip -o -4 addr show | awk -v p="$prefix" 'index($4, p) == 1 {print $2}' | head -n 1 | cut -d@ -f1)
  [ -z "$dev" ] && { echo "no interface for $prefix"; return 1; }
  tc qdisc replace dev "$dev" root netem delay "${delay}ms" || return 1
  echo "netem: ${delay}ms one-way on $dev ($prefix)"
}

if [ "$DELAY_MODE" = "netem" ]; then
  if apply_delay "$WAN_PREFIX" "$INTER_ONEWAY_MS" && apply_delay "$LAN_PREFIX" "$INTRA_ONEWAY_MS"; then
    :
  else
    echo "WARNING: tc/netem unavailable - falling back to application-level delay"
    DELAY_MODE=app; export DELAY_MODE
  fi
fi
exec "$@"
