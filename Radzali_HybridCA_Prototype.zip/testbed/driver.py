"""Experiment driver: starts sessions on all RCAs simultaneously and records end-to-end results."""
import argparse, asyncio, json, os, statistics, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from netcommon import send, recv


async def connect_retry(h, p, tries=120):
    for _ in range(tries):
        try:
            return await asyncio.open_connection(h, p)
        except OSError:
            await asyncio.sleep(1)
    raise RuntimeError(f'cannot reach {h}:{p}')


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--rcas', required=True, help='k:host:port,...')
    ap.add_argument('--sessions', type=int, default=30)
    ap.add_argument('--warmup', type=int, default=3)
    ap.add_argument('--label', default='run')
    ap.add_argument('--out', default='results')
    a = ap.parse_args()
    rcas = {}
    for item in a.rcas.split(','):
        k, h, p = item.split(':')
        rcas[int(k)] = (h, int(p))
    conns = {}
    for k, (h, p) in rcas.items():
        conns[k] = await connect_retry(h, p)
    await asyncio.sleep(2)
    for k, (r, w) in conns.items():
        for attempt in range(60):
            await send(w, dict(op='prepare'))
            try:
                await recv(r)
                break
            except Exception:
                await asyncio.sleep(1)
    participants = sorted(rcas)
    rows = []
    for s in range(a.warmup + a.sessions):
        async def one(k):
            r, w = conns[k]
            await send(w, dict(op='start', sess=s, participants=participants))
            return await recv(r)
        t0 = time.perf_counter()
        res = await asyncio.gather(*[one(k) for k in participants])
        wall = (time.perf_counter() - t0) * 1000
        keys = {x['key_hash'] for x in res}
        if len(keys) != 1:
            raise RuntimeError('RCAs derived different keys!')
        if s >= a.warmup:
            rows.append(dict(session=s, driver_wall_ms=wall, rcas=res))
        await asyncio.sleep(0.05)
    med = lambda xs: statistics.median(xs)
    summary = dict(label=a.label, m=len(participants), sessions=a.sessions,
                   total_ms_median=med([max(x['total_ms'] for x in r['rcas']) for r in rows]),
                   tsig_ms_median=med([x['tsig_ms'] for r in rows for x in r['rcas']]),
                   compute_ms_median=med([x['compute_ms'] for r in rows for x in r['rcas']]),
                   all_keys_agreed=True,
                   env=dict(DELAY_MODE_EFFECTIVE=sorted({x.get('delay_mode') for r in rows for x in r['rcas']}),
                            INTER_RTT_MS=os.environ.get('INTER_RTT_MS'), INTRA_RTT_MS=os.environ.get('INTRA_RTT_MS')))
    os.makedirs(a.out, exist_ok=True)
    json.dump(dict(summary=summary, rows=rows), open(os.path.join(a.out, f'{a.label}.json'), 'w'), indent=1)
    print(json.dumps(summary, indent=1))


if __name__ == '__main__':
    asyncio.run(main())
