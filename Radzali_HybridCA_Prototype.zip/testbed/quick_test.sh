#!/usr/bin/env bash
# Quick check (about 5-10 minutes): 2 Root CAs, one network scenario, 5 sessions.
cd "$(dirname "$0")/.."
if ! docker info >/dev/null 2>&1; then
  echo "ERROR: Docker is not running or not connected to Ubuntu."
  echo "Open Docker Desktop, wait for 'Engine running', check Settings > Resources > WSL integration > Ubuntu is ON, then try again."
  exit 1
fi
SESSIONS=5 MS=2 MODES=optimistic SCENARIOS=S2:40:2 bash testbed/run_docker.sh 2>&1 \
  | grep --line-buffered -v -E '^\s*(Container|Network) ' 
