"""Signing node: holds one key share of one RCA and answers partial-signature requests."""
import argparse, asyncio, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import tcrypto as tc
from netcommon import send, recv, dec, env_delay


def load(path):
    d = dec(open(path, 'rb').read())
    pk = tc.PublicKey(d['N'], d['e'], d['n'], d['t'], d['v'], d['vks'])
    return tc.KeyShare(d['i'], d['s'], pk)


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--keyfile', required=True)
    ap.add_argument('--port', type=int, required=True)
    ap.add_argument('--byzantine', action='store_true', help='answer with a corrupted share (fault injection)')
    a = ap.parse_args()
    share = load(a.keyfile)
    if a.byzantine:
        share = tc.KeyShare(share.i, share.s + 1, share.pk)
    delay = env_delay('INTRA_ONEWAY_MS')

    async def handle(r, w):
        try:
            while True:
                req = await recv(r)
                if req.get('op') == 'sign':
                    t0 = time.perf_counter()
                    i, xi, proof = tc.partial_sign(share, req['msg'], with_proof=req['proof'])
                    ms = (time.perf_counter() - t0) * 1000
                    resp = dict(rid=req['rid'], i=i, xi=xi, c=proof[1] if proof else None,
                                z=proof[0] if proof else None, ms=ms)
                    await send(w, resp, delay)
        except (asyncio.IncompleteReadError, ConnectionError):
            pass

    srv = await asyncio.start_server(handle, '0.0.0.0', a.port)
    print(f'node {share.i} listening on {a.port}', flush=True)
    async with srv:
        await srv.serve_forever()


if __name__ == '__main__':
    asyncio.run(main())
