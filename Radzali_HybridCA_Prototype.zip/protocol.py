"""
Authenticated session establishment among m Root CAs (RCAs).

Round 1 (broadcast):  RCA_i -> all : (ID_i, N_i, M_i, z_i = g^{r_i})
Local:                 sid = SHA3(N_1..N_m),  h_X = SHA3(sort(h_1..h_m)),  policy check on M_j
Round 2 (broadcast):  RCA_i -> all : (X_i, sigma_i)  where sigma_i = TSig_{RCA_i}(sid||h_X||z_1..z_m||i||X_i)
                       sigma_i is produced by t-of-n nodes of RCA_i (Shoup threshold RSA).
Local:                 verify sigma_j against own view, compute BD key K, K_session = HKDF(salt=h_X, K, info)
"""
import os, time, hashlib, struct
import tcrypto as tc


class RCA:
    def __init__(self, idx, m, pk, shares, metadata):
        self.idx, self.m, self.pk, self.shares, self.M = idx, m, pk, shares, metadata
        self.h = tc.digest(metadata)
        self.timing = {}

    # ----- round 1
    def r1(self):
        t0 = time.perf_counter()
        self.bd = tc.BDParty(self.idx, self.m)
        z = self.bd.round1()
        self.timing['r1'] = time.perf_counter() - t0
        return dict(id=self.idx, nonce=self.bd.nonce, M=self.M, z=z)

    # ----- round 2
    def r2(self, msgs1, policy_check=None, signers=None, faulty=None):
        """msgs1: this RCA's received view of round-1 messages (list ordered by id)."""
        t0 = time.perf_counter()
        if policy_check is not None:
            for mm in msgs1:
                if not policy_check(tc.decode_metadata(mm['M'])):
                    raise ValueError('policy mismatch with RCA %d' % mm['id'])
        self.sid = hashlib.sha3_256(b''.join(mm['nonce'] for mm in msgs1)).digest()
        self.hX = tc.composite_digest([tc.digest(mm['M']) for mm in msgs1])
        self.zs = [mm['z'] for mm in msgs1]
        X = self.bd.round2(self.zs)
        tr = tc.transcript_r2(self.sid, self.hX, self.zs, self.idx, X)
        t1 = time.perf_counter()
        # threshold signing inside the RCA: nodes produce partials in parallel;
        # critical path = one partial (max over nodes) + proof checks + combine at coordinator
        signers = signers if signers is not None else list(range(self.pk.n))
        parts, ptimes = [], []
        for i in signers:
            s = self.shares[i]
            if faulty and s.i in faulty:
                s = tc.KeyShare(s.i, s.s + 1, self.pk)
            a = time.perf_counter()
            parts.append(tc.partial_sign(s, tr))
            ptimes.append(time.perf_counter() - a)
            if len(parts) >= len(signers):
                break
        a = time.perf_counter()
        sig, rejected = tc.robust_sign(self.pk, tr, parts)
        tcomb = time.perf_counter() - a
        if sig is None:
            raise RuntimeError('fewer than t valid partial signatures')
        self.timing['r2_local'] = (t1 - t0)
        self.timing['tsig_partial_max'] = max(ptimes)
        self.timing['tsig_combine'] = tcomb
        self.rejected = rejected
        return dict(id=self.idx, X=X, sig=sig)

    # ----- key derivation
    def finish(self, msgs2, pks):
        t0 = time.perf_counter()
        Xs = [mm['X'] for mm in msgs2]
        for mm in msgs2:
            if mm['id'] == self.idx:
                continue
            tr = tc.transcript_r2(self.sid, self.hX, self.zs, mm['id'], mm['X'])
            if not pks[mm['id']].verify(tr, mm['sig']):
                raise ValueError('authentication failure for RCA %d' % mm['id'])
        t1 = time.perf_counter()
        K = self.bd.key(Xs)
        self.Ksess = tc.session_key(K, self.hX, self.sid, self.zs, Xs)
        t2 = time.perf_counter()
        self.timing['verify_sigs'] = t1 - t0
        self.timing['key'] = t2 - t1
        return self.Ksess


def run_session(rcas, policy_check=None, tamper=None, faulty=None):
    m = len(rcas)
    msgs1 = [r.r1() for r in rcas]
    views = []
    for k in range(m):
        v = [dict(x) for x in msgs1]
        if tamper is not None:
            v = tamper(k, v)
        views.append(v)
    msgs2 = [rcas[k].r2(views[k], policy_check, faulty=faulty) for k in range(m)]
    pks = {r.idx: r.pk for r in rcas}
    return [r.finish(msgs2, pks) for r in rcas]


def make_rcas(m, bits, t, n, primes_pool=None):
    algs = ['RSA', 'ECDSA-P256', 'ECDSA-P256', 'Ed25519']
    rcas = []
    for i in range(m):
        primes = primes_pool[i] if primes_pool else None
        pk, shares = tc.deal(bits, n, t, primes=primes)
        a = algs[i % len(algs)]
        M = tc.encode_metadata(a, bits if a == 'RSA' else 256, 1, 1759017600, t, n)
        rcas.append(RCA(i, m, pk, shares, M))
    return rcas


if __name__ == '__main__':
    rcas = make_rcas(3, 2048, 3, 5)
    ks = run_session(rcas, policy_check=lambda md: md['version'] == 1 and md['t'] >= 2)
    assert len(set(ks)) == 1
    print('3-RCA session ok, key', ks[0].hex()[:16], '...')

    # MITM: adversary replaces z_0 seen by RCA 2 with its own value
    rcas = make_rcas(3, 2048, 3, 5)
    def mitm(k, v):
        if k == 2:
            v[0]['z'] = tc.powmod(tc.G, 12345, tc.P2048)
        return v
    try:
        run_session(rcas, tamper=mitm); print('MITM NOT DETECTED')
    except ValueError as e:
        print('MITM detected:', e)

    # metadata substitution: RCA 1 sees altered metadata of RCA 0 (version 2)
    rcas = make_rcas(3, 2048, 3, 5)
    def meta(k, v):
        if k == 1:
            d = tc.decode_metadata(v[0]['M'])
            v[0]['M'] = tc.encode_metadata(d['alg'], d['keylen'], 2, d['timestamp'], d['t'], d['n'])
        return v
    try:
        run_session(rcas, tamper=meta); print('METADATA TAMPER NOT DETECTED')
    except ValueError as e:
        print('metadata tamper detected:', e)

    # one Byzantine node per RCA
    rcas = make_rcas(3, 2048, 3, 5)
    ks = run_session(rcas, faulty={2})
    assert len(set(ks)) == 1
    print('Byzantine node tolerated; rejected ids:', [r.rejected for r in rcas])
