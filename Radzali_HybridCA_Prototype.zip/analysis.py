"""Turns results/*.json into figures (PDF) and LaTeX table fragments for the paper."""
import json, os, sys, time, statistics
from math import comb
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import tcrypto as tc
from gmpy2 import mpz, powmod
import secrets

D = os.path.dirname(os.path.abspath(__file__))
R = os.path.join(D, 'results')
F = os.path.join(D, 'figures'); os.makedirs(F, exist_ok=True)
T = os.path.join(D, 'tables'); os.makedirs(T, exist_ok=True)

C = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100']  # validated categorical order
MK = ['o', 's', '^', 'D']
TXT, TXT2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
plt.rcParams.update({'font.family': 'serif', 'font.size': 9, 'axes.edgecolor': TXT2, 'axes.labelcolor': TXT,
                     'xtick.color': TXT2, 'ytick.color': TXT2, 'axes.spines.top': False,
                     'axes.spines.right': False, 'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.6,
                     'legend.frameon': False, 'lines.linewidth': 2, 'lines.markersize': 5})

mic = {b: json.load(open(os.path.join(R, f'micro{b}.json'))) for b in (2048, 3072)}
ses = json.load(open(os.path.join(R, 'sessions.json')))
flt = json.load(open(os.path.join(R, 'faults.json')))
med = lambda d: d['median']
out = {}

# ---------------------------------------------------------------- Table: per-operation costs
rows = []
for b in (2048, 3072):
    for r in mic[b]['results']:
        rows.append('%d & (%d,%d) & %.2f & %.2f & %.2f & %.2f & %.2f & %.3f & %d \\\\' % (
            b, r['t'], r['n'], med(r['deal']), med(r['partial_noproof']), med(r['partial_proof']),
            med(r['verify_partial']), med(r['combine']), med(r['verify_sig']), r['size_partial_bytes']))
    rows.append('\\midrule')
rows = rows[:-1]
open(os.path.join(T, 'micro.tex'), 'w').write('\n'.join(rows) + '\n')

base_rows = []
for b in (2048, 3072):
    bs = mic[b]['baseline']
    base_rows.append('%d & %.2f & %.2f & %.2f \\\\' % (b, med(bs['openssl_pkcs1']), med(bs['gmpy2_crt']), med(bs['gmpy2_nocrt'])))
open(os.path.join(T, 'baseline.tex'), 'w').write('\n'.join(base_rows) + '\n')


# ---------------------------------------------------------------- coordinator latency (compute only)
def coord(r, mode):
    if mode == 'robust':
        return med(r['partial_proof']) + r['t'] * med(r['verify_partial']) + med(r['combine']) + med(r['verify_sig'])
    return med(r['partial_noproof']) + med(r['combine']) + med(r['verify_sig'])

fig, ax = plt.subplots(figsize=(3.5, 2.5))
labels = None
k = 0
for b in (2048, 3072):
    for mode in ('robust', 'optimistic'):
        rs = mic[b]['results']
        xs = list(range(len(rs)))
        ys = [coord(r, mode) for r in rs]
        out[f'coord_{mode}_{b}'] = {f"{r['t']},{r['n']}": y for r, y in zip(rs, ys)}
        ax.plot(xs, ys, color=C[k], marker=MK[k], label=f'{b}-bit, {mode}')
        if mode == 'robust':
            ax.annotate(f'{b} robust', (xs[-1], ys[-1]), xytext=(4, 0), textcoords='offset points',
                        fontsize=7, color=TXT2, va='center')
        labels = [f"({r['t']},{r['n']})" for r in rs]
        k += 1
ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels)
ax.set_xlabel('Threshold configuration $(t,n)$'); ax.set_ylabel('Signing time at coordinator (ms)')
ax.set_ylim(bottom=0); ax.set_xlim(-0.3, len(labels) - 0.2)
ax.legend(fontsize=7, loc='upper left')
fig.tight_layout(); fig.savefig(os.path.join(F, 'fig_tsig_latency.pdf')); fig.savefig(os.path.join(F, 'fig_tsig_latency.png'), dpi=150); plt.close(fig)

# ---------------------------------------------------------------- session compute vs m, with baselines
# cost of one 256-bit-exponent exponentiation in the 2048-bit group, taken from the same machine's
# measurements: unauthenticated BD with m = 2 performs three such exponentiations per party
dh_ms = med([s for s in ses['results'] if s['m'] == 2][0]['bd_compute']) / 3
r35 = [r for r in mic[2048]['results'] if (r['t'], r['n']) == (3, 5)][0]
tsig35 = coord(r35, 'robust')
vs = med(r35['verify_sig'])
ms_ = [s['m'] for s in ses['results']]
prop = [med(s['total']) for s in ses['results']]
unauth = [med(s['bd_compute']) for s in ses['results']]
mesh = [(m - 1) * (tsig35 + vs + 2 * dh_ms) for m in ms_]
out.update(dh_exp_ms=dh_ms, tsig35_robust_ms=tsig35, session_total=dict(zip(ms_, prop)),
           session_unauth=dict(zip(ms_, unauth)), mesh=dict(zip(ms_, mesh)))
fig, ax = plt.subplots(figsize=(3.5, 2.5))
for k, (ys, lab) in enumerate([(prop, 'Proposed (1 threshold sig./RCA)'),
                               (mesh, 'Pairwise authenticated DH mesh'),
                               (unauth, 'Unauthenticated BD (no trust)')]):
    ax.plot(ms_, ys, color=C[k], marker=MK[k], label=lab)
ax.set_xlabel('Number of participating RCAs $m$'); ax.set_ylabel('Computation per RCA (ms)')
ax.set_ylim(bottom=0); ax.set_xticks(ms_)
ax.legend(fontsize=7, loc='upper left')
fig.tight_layout(); fig.savefig(os.path.join(F, 'fig_session_compute.pdf')); fig.savefig(os.path.join(F, 'fig_session_compute.png'), dpi=150); plt.close(fig)

# ---------------------------------------------------------------- end-to-end session latency, network scenarios
SC = [('S1 single region', 2, 1), ('S2 continental', 40, 2), ('S3 intercontinental', 150, 2),
      ('S4 S3 + dispersed nodes', 150, 40)]
fig, ax = plt.subplots(figsize=(3.5, 3.0))
lat = {}
for k, (name, rin, rintra) in enumerate(SC):
    ys = [rin + rintra + p for p in prop]
    lat[name] = dict(zip(ms_, ys))
    ax.plot(ms_, ys, color=C[k], marker=MK[k], label=f'{name} ({rin}/{rintra} ms)')
ax.set_xlabel('Number of participating RCAs $m$'); ax.set_ylabel('Session establishment (ms)')
ax.set_ylim(bottom=0); ax.set_xticks(ms_)
ax.legend(fontsize=6.5, loc='upper center', bbox_to_anchor=(0.45, -0.28), ncol=2, columnspacing=1.0)
ax.set_ylim(top=max(max(v.values()) for v in lat.values()) * 1.1)
fig.tight_layout(); fig.savefig(os.path.join(F, 'fig_session_latency.pdf'), bbox_inches='tight'); fig.savefig(os.path.join(F, 'fig_session_latency.png'), dpi=150, bbox_inches='tight'); plt.close(fig)
out['latency_scenarios'] = lat

# ---------------------------------------------------------------- session table
srows = []
for s in ses['results']:
    m = s['m']
    srows.append('%d & %.1f & %.1f & %.2f & %.1f & %.1f & %d & %d \\\\' % (
        m, med(s['bd_compute']), med(s['tsig']), med(s['verify']), med(s['total']), mesh[ms_.index(m)],
        s['bytes_sent_per_rca'], s['total_bytes_unicast']))
open(os.path.join(T, 'sessions.tex'), 'w').write('\n'.join(srows) + '\n')

# ---------------------------------------------------------------- faults table
frows = []
for f in flt['results']:
    frows.append('%s & %d & %.0f\\%% & %.1f & %.1f \\\\' % (f['kind'].capitalize(), f['faulty'], 100 * f['success_rate'],
                                                         med(f['coordinator']), f['mean_rejected']))
open(os.path.join(T, 'faults.tex'), 'w').write('\n'.join(frows) + '\n')

# ---------------------------------------------------------------- availability / compromise analysis
def avail(t, n, a):
    return sum(comb(n, k) * a ** k * (1 - a) ** (n - k) for k in range(t, n + 1))

cfgs = [(1, 1), (2, 3), (3, 5), (4, 7)]
arows = []
for (t, n) in cfgs:
    A = [avail(t, n, a) for a in (0.99, 0.999)]
    P = [avail(t, n, p) for p in (0.01, 0.05)]  # probability >= t nodes compromised
    arows.append('(%d,%d) & %.2e & %.2e & %.2e & %.2e \\\\' % (t, n, 1 - A[0], 1 - A[1], P[0], P[1]))
    out[f'avail_{t}_{n}'] = dict(a099=A[0], a0999=A[1], comp001=P[0], comp005=P[1])
open(os.path.join(T, 'availability.tex'), 'w').write('\n'.join(arows) + '\n')

out['env'] = mic[2048]['env']
out['baseline'] = {b: {k: med(v) for k, v in mic[b]['baseline'].items() if isinstance(v, dict)} for b in (2048, 3072)}
json.dump(out, open(os.path.join(R, 'derived.json'), 'w'), indent=1, default=str)
print(json.dumps({k: out[k] for k in ('dh_exp_ms', 'tsig35_robust_ms', 'session_total', 'mesh', 'baseline')}, indent=1, default=str))
